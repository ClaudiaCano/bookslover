<?php

// Navbar
$nav_login = 'iniciar sesión';

// Home
$home_titulo_slider = 'bestsellers';
$home_titulo_izquierda = 'libros por descubrir';
$home_titulo_derecha = 'autores';
$ver_mas = 'ver más';

// Book
$book_descripcion = "Descripción";
$book_detalles = "Detalles";
?>