<?php
/*------------------- Textos en Castellano -------------------*/ 

// Navbar
$nav_login = 'iniciar sesión';

// Home
$home_titulo_slogan = 'viaja, descubre, vive, ama...';
$home_texto_slogan = 'Todos tus libros, incluso los que aún no sabes que formarán parte de ti, en un solo sitio. <br><br>Todas tus vidas, experiencias, amores y conocimientos te estan buscando. <br><br>¿A qué esperas?';
$home_titulo_slider = 'bestsellers';
$home_titulo_izquierda = 'libros por descubrir';
$home_titulo_derecha = 'autores';
$ver_mas = 'ver más';

// Book
$book_descripcion = "Descripción";
$book_detalles = "Detalles";
?>