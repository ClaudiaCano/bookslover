<footer class="footer py-5">
	<div class="row">
		<div id="copyright" class="col-lg-3 col-12">
			<a class="navbar-brand" href="../index.php"><img id="footer-logo" src="../img/bookslover_1_max.png"></a>
			<ul>
				<li></li>
				<li>&copy; 2020 bookslover </li>
			</ul>
		</div>
		<div class="col-lg-3 col-6">
			<h4>ayuda & FAQs</h4>
			<ul>
				<a class="" href=""><li>compra online</li></a>
				<a class="" href=""><li>envío</li></a>
				<a class="" href=""><li>facturación</li></a>
				<a class="" href=""><li>cambios & devoluciones</li></a>
			</ul>
		</div>
		<div class="col-lg-3 col-6">
			<h4>bookslover</h4>
			<ul>
				<a class="" href=""><li>sobre bookslover</li></a>
				<a class="" href=""><li>sala de prensa</li></a>
				<a class="" href=""><li>trabaja con nosotros</li></a>
				<a class="" href=""><li>sitemap</li></a>
				<a class="" href=""><li>contacto</li></a>
			</ul>
		</div>
		<div class="col-lg-3 col-12">
			<div class="row row-cols-sm-2 row-cols-md-3 row-cols-lg-3 row-cols-xl-6">
				<div class="col-2">
					<a class="rrss" href=""><img src="../img/icon_insta.png" alt="instagram"></a>
				</div>
				<div class="col-2">
					<a class="rrss" href=""><img src="../img/icon_twitter.png" alt="twitter"></a>
				</div>
				<div class="col-2">
					<a class="rrss" href=""><img src="../img/icon_face.png" alt="facebook"></a>
				</div>
				<div class="col-2">
					<a class="rrss" href=""><img src="../img/icon_snap.png" alt="snapchat"></a>
				</div>
				<div class="col-2">
					<a class="rrss" href=""><img src="../img/icon_pint.png" alt="pinterest"></a>
				</div>
				<div class="col-2">
					<a class="rrss" href=""><img src="../img/icon_drib.png" alt="dribbble"></a>
				</div>
			</div>
		</div>
	</div>
</footer>